Please visit https://ezfn.net and join my Discord to stay updated about this https://discord.gg/n9ym28s
